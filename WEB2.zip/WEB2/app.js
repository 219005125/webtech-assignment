const express = require('express');
const path = require("path");
const bodyParser= require('body-parser');
const MongoClient = require('mongodb').MongoClient
const url = 'mongodb://127.0.0.1:27017'
const dbName = 'employeedb'
let db
const app = express();


MongoClient.connect(url, {
    useUnifiedTopology: true
  }, (err, client) => {
    if (err) return console.error(err)
    console.log('Connected to Database')
    db = client.db(dbName)
    todocollection = db.collection('todo')
    employeecollection = db.collection('employees')
    console.log(`Connected MongoDB: ${url}`)
    console.log(`Database: ${dbName}`)
  })


app.set("views", path.join(__dirname, "src"));
app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "src/public")));


app.listen(8000,function(){
    console.log('listening on 8000')
});

app.use(bodyParser.urlencoded({ extended: true }))

app.get('/', (req, res) => {
    res.render('index');
  });

app.post('/', (req, res) => {
    console.log(req.body)
 })


  app.get('/', (req, res) => {
    const cursor = db.collection('todo').find()
    db.collection('todo').find().toArray()
      .then(results => {
        res.render("index", {todo: results });
        console.log(results)
      })
      .catch(error => console.error(error))
      
  })